#TODO
#upgrade zombie ai
#make weapon sprites
#add animations
#more sounds
#add shop/weapon upgrades
#make shotgun reload dynamic
#add shotgun spread
#get inspired

import pygame # type: ignore
import math
import random
import sys
import json
import os

# Initialize Pygame
pygame.init()
pygame.mixer.init()
pygame.mixer.set_num_channels(32)
Reloadchannel = pygame.mixer.Channel(0)

#sounds
handgun_reload = pygame.mixer.Sound("sounds/handgun_reload.wav")
firing_sound = pygame.mixer.Sound("sounds/generic_firing.wav")
rifle_reload = pygame.mixer.Sound("sounds/rifle_reload_1.wav")
rifle_shooting = pygame.mixer.Sound("sounds/rifle_shoot.wav")
shotgun_reload = pygame.mixer.Sound("sounds/shotgun_reload.wav")
shotgun_shooting = pygame.mixer.Sound("sounds/shotgun_firing.wav")

# Set up display
WIDTH, HEIGHT = 1200, 640
TILE_SIZE = 40
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Gridworld")
pygame.mouse.set_visible(False)

#images/sprites
player_img = pygame.image.load("sprites/Soldier_1.png").convert_alpha()
zomb1_img = pygame.image.load("sprites/zombie_1.png").convert_alpha()
zomb2_img = pygame.image.load("sprites/zombie_2.png").convert_alpha()
cursor_img = pygame.image.load("sprites/crosshair.png").convert_alpha()
bullet_img = pygame.image.load("sprites/bullet.png").convert_alpha()
grass_img = pygame.image.load("sprites/tiles/grass.png").convert_alpha()
dirt_img = pygame.image.load("sprites/tiles/dirt.png").convert_alpha()
speedy1_img = pygame.image.load("sprites/zombie_1(old).png").convert_alpha()
speedy2_img = pygame.image.load("sprites/zombie_2(old).png").convert_alpha()
tanky1_img = pygame.image.load("sprites/tanky_1.png").convert_alpha()
tanky2_img = pygame.image.load("sprites/tanky_2.png").convert_alpha()
normzombsprites = [zomb1_img, zomb2_img]
speedyzombsprites = [speedy1_img, speedy2_img]
tankzombsprites = [tanky1_img, tanky2_img]

# setting up UI hitboxes
pause_button = pygame.Rect(10, 10, 80, 30)
HOTBAR_RECT = pygame.Rect(10, HEIGHT - 60, 600, 50)
Inventory_button = pygame.Rect(630, HEIGHT-60, 50, 50)
inv_exit_button = pygame.Rect(10, 10, 50, 50)
resume_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 - 60, 120, 40)
options_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 - 10, 120, 40)
quit_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 + 40, 120, 40)
back_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT - 80, 120, 40)
mode_toggle_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 + 90, 120, 40)
save_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 + 140, 120, 40)
load_button = pygame.Rect(WIDTH // 2 - 60, HEIGHT // 2 + 190, 120, 40)
input_box = pygame.Rect(WIDTH // 2 - 100, 160, 200, 30)
zombie_toggle_button = pygame.Rect(WIDTH // 2 - 100, 200, 200, 30)
survival_toggle_button = pygame.Rect(WIDTH // 2 - 100, 240, 200, 30)
zombie_wave_button = pygame.Rect(650, 10, 120, 50)

# setting up camera variables
camera_x = 0
camera_y = 0
camera_speed = 10

suppress_click = 0  # prevents accidental tile placement

# set up font
pygame.font.init()
font = pygame.font.SysFont('Times New Roman', 16)
waveready_label = font.render("click or press G start wave", True, (0,0,0))

# Set up clock
clock = pygame.time.Clock()

# setting up tilemap
ROWS = HEIGHT // TILE_SIZE
COLS = WIDTH // TILE_SIZE

# Tile IDs
TILE_EMPTY = 0
TILE_GRASS = 1
TILE_WATER = 2
TILE_SHALLOW = 3
TILE_DIRT = 4
TILE_STONE = 5
TILE_SPAWN = 6
TILE_TNT = 7
TILE_FIRE = 8
TILE_SMOKE = 9

# Tile colors
TILE_INFO = {
    TILE_EMPTY: {"name": "Empty", "color": (200, 200, 200)},
    TILE_GRASS: {"name": "Grass", "color": (0, 200, 0), "texture": grass_img},
    TILE_WATER: {"name": "Water", "color": (0, 50, 255)},
    TILE_SHALLOW: {"name": "Shallow", "color": (0, 150, 255)},
    TILE_DIRT: {"name": "Dirt", "color": (139, 69, 19), "texture": dirt_img},
    TILE_STONE: {"name": "Stone", "color": (80, 80, 80)},
    TILE_SPAWN: {"name": "Spawn", "color": (125, 125, 0)},
    TILE_TNT: {"name": "TNT", "color": (200, 10, 10)},
    TILE_FIRE: {"name": "Fire", "color": (255, 85, 0)}, #color options: (180, 0, 0), (255, 85, 0), (255, 170, 0), (255, 120, 30) 
    TILE_SMOKE: {"name": "Smoke", "color": (120, 120, 120, 100)}# another color: (50, 50, 50)
}


#setting up weapons
arsenal = {
    "handgun": {"name": "Handgun","ammo": 12, "maxammo": 12, "damage": 15, "firerate": 15, "shootsfx": firing_sound, "reloadsfx": handgun_reload, "bulletlife": 0.75, "speed": 7, "mobility": 1, "image": bullet_img},
    "rifle": {"name": "Rifle", "ammo": 45, "maxammo": 45, "damage": 12, "firerate": 6, "shootsfx": rifle_shooting, "reloadsfx": rifle_reload, "bulletlife": 1.5, "speed": 10, "mobility": 0.5, "image": bullet_img},
    "shotgun": {"name": "Shotgun","ammo": 8, "maxammo": 8, "damage": 100, "firerate": 30, "shootsfx": shotgun_shooting, "reloadsfx": shotgun_reload, "bulletlife": 0.5, "speed": 8, "mobility": 0.5, "pellets": 6, "spread": 15, "image": bullet_img}
}

#ZOMBIES!!!
ZOMBIES = {"speedy": {"name": "sprinter", "health": 20, "speed": 2.5, "damage": (15, 5), "value": (3, 2), "sprites": speedyzombsprites},
           "normal": {"name": "zombie", "health": 30, "speed": 1.5, "damage": (30, 15), "value": (0, 1)},
           "tankyzombie": {"name": "tank", "health": 50, "speed": 1, "damage": (35, 25), "value": (7, 3), "sprites": tankzombsprites}
    
}

PREFIX = "Gridworld."
Inventory = [TILE_EMPTY, TILE_GRASS, TILE_DIRT, TILE_WATER, TILE_SHALLOW, TILE_STONE, TILE_TNT, TILE_FIRE, TILE_SMOKE, TILE_SPAWN]
Hotbar = Inventory[:10]
selected_tile = 1
mousewheeldown = False
current_screen = "game"  # can be "game", "pause", "options", "resuming", and now "inventory"
world_name = "MyWorld"
editing_name = False
pause_cooldown = 0
spawn_found = False
game_mode = "build"  # or "play"
player = None
spawn_point = (7,7)
pause_delay_frames = 0
projectiles = []
zombies = []
spawn_Zombies = True
zombieframecount = 0
solidlist = [TILE_STONE]
survival = True
save_prelabel = None
load_prelabel = None
label_refresh = 0
waveready = True
wavenum = 1
difficulty = "impossible"
difficulty_index = {"easy": {"wave mult": 0.5},
                    "normal": {"wave mult": 1},
                    "hard": {"wave mult": 1.5},
                    "impossible": {"wave mult": 2}
    
}

class Player:
    def __init__(self, Rect, Health, Speed, Color, arsenal, image=player_img):
        self.rect = Rect
        self.health = Health
        self.speed = Speed
        self.color = Color
        self.points = 100
        self.weapons = list(arsenal.keys())
        self.weapon = 0
        self.firedelay = 0
        self.totaldelay = 0
        self.arsenal = arsenal
        self.firing = False
        self.reloading = False
        self.img = image
    def update(self, surface=screen):
        if game_mode == "play":
            if self.firedelay > 0:
                self.firedelay -= 1
            elif self.firedelay < 0:
                self.firedelay = 0
            if self.reloading and self.firedelay == 0:
                self.reloading = False
            if self.health < 100:
                self.health += 0.25
            if self.health < 25:
                self.health += 0.5
            if self.health > 100:
                self.health = 100
            #que up movement
            xmove = 0
            ymove = 0
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LSHIFT]:
                if keys[pygame.K_w]:
                    ymove -= 1.5*self.speed
                if keys[pygame.K_s]: 
                    ymove += 1.5*self.speed
                if keys[pygame.K_a]: 
                    xmove -= 1.5*self.speed
                if keys[pygame.K_d]: 
                    xmove += 1.5*self.speed
            else:
                if keys[pygame.K_w]:
                    ymove -= self.speed
                if keys[pygame.K_s]: 
                    ymove += self.speed
                if keys[pygame.K_a]: 
                    xmove -= self.speed
                if keys[pygame.K_d]: 
                    xmove += self.speed
            #process movement
            if xmove != 0 and ymove != 0:
                norm = 1/math.sqrt(2)
                
                xmove *= norm
                ymove *= norm
            self.rect.x += xmove
            self.rect.y += ymove
            
            #sprite setup/rotation
            mouse_x, mouse_y = pygame.mouse.get_pos()

            # Get center of player for rotation
            player_center_x = self.rect.x-1 + self.img.get_width() // 2
            player_center_y = self.rect.y-1 + self.img.get_height() // 2
            dx = mouse_x - player_center_x
            dy = mouse_y - player_center_y
            angle = math.degrees(math.atan2(-dy, dx))
            rotated_img = pygame.transform.rotate(self.img, angle-90)
            rotated_rect = rotated_img.get_rect(center=(player_center_x, player_center_y))
            #pygame.draw.rect(surface, self.color, self.rect)
            surface.blit(rotated_img, rotated_rect.topleft)
            
            self.draw_ammo_bar(screen)
            if self.firing:
                self.shoot()
            
    def reset(self, positionx, positiony):
        self.rect = pygame.Rect(positionx, positiony, self.rect.width, self.rect.height)
    
    def draw_health_bar(self, screen):
        pygame.draw.rect(screen, (20, 20, 20, 90), pygame.Rect(100, 10, 500, 20))
        if self.health > 0:
            pygame.draw.rect(screen, (250, 0, 0), pygame.Rect(102, 12, int(4.975*self.health), 16))
            
    def draw_ammo_bar(self,screen = screen):
        pygame.draw.rect(screen, (220, 220, 0), pygame.Rect(WIDTH-40, HEIGHT-70, 20, 60))
        ammo = self.arsenal[self.weapons[self.weapon]]["ammo"]
        maxammo = self.arsenal[self.weapons[self.weapon]]["maxammo"]
        if ammo >= 0 and not self.reloading:
            height = 55*(ammo/maxammo)
        elif self.reloading:
            height = 55-55*(self.firedelay/self.totaldelay)
        else:
            height = 55
        pygame.draw.rect(screen, (0,0,0,50), pygame.Rect(WIDTH-39, HEIGHT-66.5, 18, 55-height))
        font = pygame.font.Font(None, 24)
        weapon_label = font.render(self.weapons[self.weapon].upper(), True, (255, 255, 255))
        above_label = font.render(self.weapons[self.weapon - 1].upper(), True, (150, 150, 150))
        below_label = font.render(self.weapons[self.weapon - (len(self.weapons)-1)].upper(), True, ((150, 150, 150)))
        screen.blit(below_label, (WIDTH-100, HEIGHT-20))
        screen.blit(above_label, (WIDTH-100, HEIGHT-80))
        screen.blit(weapon_label, (WIDTH-100, HEIGHT-50))

    
    def reload(self):
        if player.arsenal[player.weapons[player.weapon]]["ammo"] == player.arsenal[player.weapons[player.weapon]]["maxammo"]:
            return
        reloadtime = 120/self.arsenal[self.weapons[self.weapon]]["mobility"]
        self.firedelay = reloadtime
        self.totaldelay = reloadtime
        self.arsenal[self.weapons[self.weapon]]["ammo"] = self.arsenal[self.weapons[self.weapon]]["maxammo"]
        sound = self.arsenal[self.weapons[self.weapon]].get("reloadsfx", handgun_reload)
        Reloadchannel.play(sound)
        self.reloading = True
    
    def shoot(self):
        if self.firedelay == 0:
            if self.arsenal[self.weapons[self.weapon]]["ammo"] > 0:
                weapon_data = self.arsenal[self.weapons[self.weapon]]  # use current weapon
                projectiles.append(Projectile(self.rect.centerx, self.rect.centery, weapon_data))
                self.arsenal[self.weapons[self.weapon]]["ammo"] -= 1
                sound = self.arsenal[self.weapons[self.weapon]].get("shootsfx", firing_sound)
                sound.play(maxtime=0, fade_ms=0)
                self.firedelay = self.arsenal[self.weapons[self.weapon]]["firerate"]
            else:
                self.reload()
            

player = Player(pygame.Rect(100, 100, 30, 30), 100, 2, (255, 0, 0), arsenal)

class Projectile:
    def __init__(self, x, y, weapon_data):
        self.width = 6
        self.height = 6
        self.x = float(x)
        self.y = float(y)
        self.speed = weapon_data.get("speed", 7)
        self.damage = weapon_data.get("damage", 10)
        self.img = weapon_data.get("image", bullet_img)
        self.lifetime = weapon_data.get("bulletlife", 1)*60
        self.screen_width = WIDTH
        self.screen_height = HEIGHT

        mx, my = pygame.mouse.get_pos()
        dx = mx - x
        dy = my - y
        dist = math.hypot(dx, dy)
        if dist == 0:
            dx, dy, dist = 0, -1, 1

        self.vel_x = (dx / dist) * self.speed
        self.vel_y = (dy / dist) * self.speed

        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
        
        proj_center_x = self.rect.x + self.img.get_width() // 2
        proj_center_y = self.rect.y + self.img.get_height() // 2
        dx = mouse_x - proj_center_x
        dy = mouse_y - proj_center_y
        self.angle = math.degrees(math.atan2(-dy, dx))

    def draw(self, surface):
        proj_center_x = self.rect.x-15 + self.img.get_width() // 2
        proj_center_y = self.rect.y-15 + self.img.get_height() // 2
        rotated_img = pygame.transform.rotate(self.img, self.angle)
        rotated_rect = rotated_img.get_rect(center=(proj_center_x, proj_center_y))
        
        surface.blit(rotated_img, rotated_rect.topleft)


    def update(self):
        self.x += self.vel_x
        self.y += self.vel_y
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

        self.lifetime -= 1

        # Remove if expired or off-screen
        if (self.lifetime <= 0 or
            self.rect.right < 0 or
            self.rect.left > self.screen_width or
            self.rect.bottom < 0 or
            self.rect.top > self.screen_height):
            return False
        return True

class Zombie:
    def __init__(self, player_rect, selfstats = ZOMBIES["normal"], screen_width = WIDTH, screen_height = HEIGHT):
        self.stats = selfstats
        self.size = self.stats.get("size", 30)
        self.speed = self.stats.get("speed", 1.5)
        self.health = self.stats.get("health", 30)
        self.damagestat = self.stats.get("damage", (30, 15))
        zombsprites = self.stats.get("sprites", normzombsprites)
        self.img = random.choice(zombsprites)
        spawns = random.choice([((0, screen_width - self.size),(0, self.size * 2)),
                                ((0, self.size * 2),(0, screen_height - self.size)),
                                ((screen_width - self.size*3, screen_width),(0, screen_height - self.size)),
                                ((0, screen_width - self.size),(screen_height - self.size * 3, screen_height - self.size))
                                ])
        self.x = float(random.randint(spawns[0][0], spawns[0][1]))
        self.y = float(random.randint(spawns[1][0], spawns[1][1]))
        self.rect = pygame.Rect(int(self.x), int(self.y), self.size, self.size)
        self.player_rect = player_rect
        self.attackcharge = 0

    def update(self):
        dx = self.player_rect.x - self.x
        dy = self.player_rect.y - self.y
        dist = math.hypot(dx, dy)
        if dist != 0:
            self.x += (dx / dist) * self.speed
            self.y += (dy / dist) * self.speed
            self.rect.x = int(self.x)
            self.rect.y = int(self.y)
            if collides_with_solid(self.rect, solidlist):
                self.x -= (dx / dist) * self.speed
                self.y -= (dy / dist) * self.speed

    def draw(self, surface):
        zomb_center_x = self.rect.x + self.img.get_width() // 2
        zomb_center_y = self.rect.y + self.img.get_height() // 2
        dx = self.player_rect.centerx - zomb_center_x
        dy = self.player_rect.centery - zomb_center_y
        angle = math.degrees(math.atan2(-dy, dx))
        rotated_img = pygame.transform.rotate(self.img, angle-90)
        rotated_rect = rotated_img.get_rect(center=(zomb_center_x, zomb_center_y))
        
        surface.blit(rotated_img, rotated_rect.topleft)
    
    def attack(self, classed_entity):
        self.attackcharge += 1
        if self.attackcharge >= self.damagestat[0]:
            self.attackcharge = 0
            classed_entity.health -= self.damagestat[1]

class Tile:
    def __init__(self, tile_id):
        self.tile_id = tile_id
        self.updated = False
        self.spread_timer = 0
        self.life_timer = 0
        if tile_id in [TILE_FIRE, TILE_SMOKE]:
            self.maxlife = random.randint(30,90)

    def update(self, row, col, world):
        if self.tile_id == TILE_GRASS:
            self.spread_timer += 1
            if self.spread_timer >= 60:
                self.spread_timer = 0
                for dy in [-1, 1]:
                    r = row + dy
                    if 0 <= r < ROWS and world[r][col].tile_id == TILE_DIRT:
                        world[r][col] = Tile(TILE_GRASS)
                for dx in [-1, 1]:
                    c = col + dx
                    if 0 <= c < COLS and world[row][c].tile_id == TILE_DIRT:
                        world[row][c] = Tile(TILE_GRASS)

        if self.tile_id == TILE_WATER:
            self.spread_timer += 1
            if self.spread_timer >= 20:
                self.spread_timer = 0
                for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
                    ny, nx = row + dy, col + dx
                    if 0 <= ny < ROWS and 0 <= nx < COLS and world[ny][nx].tile_id == TILE_EMPTY:
                        world[ny][nx] = Tile(TILE_SHALLOW)

        if self.tile_id == TILE_SHALLOW:
            self.spread_timer += 1
            if self.spread_timer >= 30:
                self.spread_timer = 0

                has_water_neighbor = False
                water_adjacent_count = 0
                for dy in [-1, 0, 1]:
                    for dx in [-1, 0, 1]:
                        ny, nx = row + dy, col + dx
                        if 0 <= ny < ROWS and 0 <= nx < COLS:
                            if world[ny][nx].tile_id == TILE_WATER:
                                has_water_neighbor = True
                                break
                for dy, dx in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
                    ny, nx = row + dy, col + dx
                    if 0 <= ny <ROWS and 0 <= nx < COLS:
                        if world[ny][nx].tile_id == TILE_WATER:
                            has_water_neighbor = True
                            break

                if has_water_neighbor:
                    for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
                        ny, nx = row + dy, col + dx
                        if 0 <= ny < ROWS and 0 <= nx < COLS and world[ny][nx].tile_id == TILE_EMPTY:
                            world[ny][nx] = Tile(TILE_SHALLOW)
                        elif 0 <= ny < ROWS and 0 <= nx < COLS and world[ny][nx].tile_id == TILE_WATER:
                            water_adjacent_count +=1
                if water_adjacent_count >= 2:
                    world[row][col] = Tile(TILE_WATER)
        
        if self.tile_id == TILE_TNT:
            self.life_timer += 1
            if self.life_timer >= 50:
                self.life_timer = 0
                for dx in [-2, -1, 0, 1, 2]:
                    for dy in [-2, -1, 0, 1, 2]:
                        nx, ny = col + dx, row + dy
                        if 0 <= nx < COLS and 0 <= ny < ROWS and world[ny][nx].tile_id != TILE_STONE:
                            if world[ny][nx].tile_id == TILE_TNT:
                                if ny == row and nx == col:
                                    world[ny][nx] = Tile(TILE_FIRE)
                                    world[ny][nx].maxlife = 10
                                elif world[ny][nx].life_timer < 40:
                                    world[ny][nx].life_timer = 40
                            else:
                                world[ny][nx] = Tile(TILE_FIRE)
                            #world[ny][nx] = Tile(TILE_FIRE)
                            #world[ny][nx].maxlife = 10
        if self.tile_id == TILE_FIRE:
            self.life_timer += 1
            if self.life_timer >= self.maxlife:
                self.life_timer = 0
                world[row][col] = Tile(TILE_SMOKE)
        if self.tile_id == TILE_SMOKE:
            self.life_timer += 1
            if self.life_timer >= self.maxlife // 2:
                self.life_timer = 0
                world[row][col] = Tile(TILE_EMPTY)

world = [[Tile(TILE_EMPTY) for _ in range(COLS)] for _ in range(ROWS)]

def WORLD_RESET():
    for row in range(ROWS):
        for col in range(COLS):
            world[row][col] = Tile(TILE_EMPTY)

def draw_grid():
    for row in range(ROWS):
        for col in range(COLS):
            tile = world[row][col]
            world_x = col * TILE_SIZE - camera_x
            world_y = row * TILE_SIZE - camera_y
            rect = pygame.Rect(world_x, world_y, TILE_SIZE, TILE_SIZE)
            texture = TILE_INFO.get(tile.tile_id, {}).get("texture")
            color = TILE_INFO.get(tile.tile_id, {"color": (255, 0, 255)})["color"]
            
            if texture:
                # Scale the texture to tile size
                scaled_texture = pygame.transform.scale(texture, (TILE_SIZE, TILE_SIZE))
                screen.blit(scaled_texture, (world_x, world_y))
            else:
                pygame.draw.rect(screen, color, rect)
            
            pygame.draw.rect(screen, (50, 50, 50), rect, 1)

def place_tile():
    global suppress_click
    if suppress_click > 0:
        suppress_click -= 1
        return
    mouse_pos = pygame.mouse.get_pos()
    if pause_button.collidepoint(mouse_pos) or HOTBAR_RECT.collidepoint(mouse_pos):
        return
    world_x = mouse_pos[0] + camera_x
    world_y = mouse_pos[1] + camera_y
    col = world_x // TILE_SIZE
    row = world_y // TILE_SIZE
    if 0 <= row < ROWS and 0 <= col < COLS:
        if game_mode == "build":
            if pygame.mouse.get_pressed()[0]:
                if Hotbar[selected_tile] == TILE_SPAWN:
                    # Remove old spawn point
                    global spawn_point
                    if spawn_point:
                        old_row, old_col = spawn_point
                        world[old_row][old_col] = Tile(TILE_EMPTY)
                    spawn_point = (row, col)
                world[row][col] = Tile(Hotbar[selected_tile])
            elif pygame.mouse.get_pressed()[2]:
                if world[row][col].tile_id == TILE_SPAWN:
                    spawn_point = None
                world[row][col] = Tile(TILE_EMPTY)
        else:
            if pygame.mouse.get_pressed()[2]:
                if Hotbar[selected_tile] == TILE_SPAWN:
                    # Remove old spawn pointds
                    if spawn_point:
                        old_row, old_col = spawn_point
                        world[old_row][old_col] = Tile(TILE_EMPTY)
                    spawn_point = (row, col)
                world[row][col] = Tile(Hotbar[selected_tile])

def update_tiles():
    for row in range(ROWS):
        for col in range(COLS):
            world[row][col].updated = False
    for row in range(ROWS):
        for col in range(COLS):
            tile = world[row][col]
            if not tile.updated:
                tile.update(row, col, world)
                tile.updated = True

def draw_hotbar(button=True):
    pygame.draw.rect(screen, (50, 50, 50), HOTBAR_RECT, border_radius=8)
    for i, tile_id in enumerate(Hotbar):
        x = 20 + i * 60
        y = HEIGHT - 50
        color = TILE_INFO[tile_id]["color"]
        texture = TILE_INFO[tile_id].get("texture")
        name = TILE_INFO[tile_id]["name"]
        tile_rect = pygame.Rect(x, y, 40, 40)
        if texture:
            screen.blit(texture, tile_rect)
        else:
            pygame.draw.rect(screen, color, tile_rect)
        label = font.render(name, True, (255, 255, 255))
        label_rect = label.get_rect(center=(x + 20, y + 25))
        screen.blit(label, label_rect)
        if tile_id == Hotbar[selected_tile]:
            pygame.draw.rect(screen, (255, 255, 0), tile_rect, 3)
        else:
            pygame.draw.rect(screen, (0, 0, 0), tile_rect, 1)
    if button:
        pygame.draw.rect(screen, (50, 50, 50), Inventory_button, border_radius=8)
        tempfont = pygame.font.Font(None, 15)
        label = tempfont.render("Inventory", True, (255, 255, 255))
        label_rect = label.get_rect(center = (Inventory_button.center))
        screen.blit(label, label_rect)

def draw_pause_button():
    pygame.draw.rect(screen, (100, 100, 100), pause_button, border_radius=6)
    label = font.render("Pause", True, (255, 255, 255))
    label_rect = label.get_rect(center=pause_button.center)
    screen.blit(label, label_rect)

def draw_points():
    label = font.render(f"Points: {player.points}", True, (255, 255, 0))
    screen.blit(label, (WIDTH - 150, 30))
    wavelabel = font.render(f"Wave number {wavenum-1}", True, (20, 180, 20))
    screen.blit(wavelabel, (WIDTH - 160,  50))

def draw_game_mode():
    text = f"Mode: {'PLAY' if game_mode == 'play' else 'BUILD'}"
    color = (255, 0, 0) if game_mode == "play" else (0, 255, 255)
    label = font.render(text, True, color)
    screen.blit(label, (WIDTH - 130, 10))

def draw_pause_menu():
    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.set_alpha(150)
    overlay.fill((0, 0, 0))
    screen.blit(overlay, (0, 0))

    # Buttons
    pygame.draw.rect(screen, (70, 70, 70), resume_button, border_radius=8)
    pygame.draw.rect(screen, (70, 70, 70), options_button, border_radius=8)
    pygame.draw.rect(screen, (70, 70, 70), quit_button, border_radius=8)
    pygame.draw.rect(screen, (100, 100, 100), mode_toggle_button, border_radius=8)

    # Labels
    if save_prelabel == None:
        save_postlabel = "save"
    else:
        save_postlabel = save_prelabel
    if load_prelabel == None:
        load_postlabel = "load"
    else:
        load_postlabel = load_prelabel
    save_label = font.render(f"{save_postlabel}", True, (255, 255, 255))
    load_label = font.render(f"{load_postlabel}", True, (255, 255, 255))
    resume_label = font.render("Resume", True, (255, 255, 255))
    options_label = font.render("Options", True, (255, 255, 255))
    quit_label = font.render("Quit", True, (255, 255, 255))
    toggle_label = font.render("To " + ("Build" if game_mode == "play" else "Play"), True, (255, 255, 255))

    screen.blit(resume_label, resume_label.get_rect(center=resume_button.center))
    screen.blit(options_label, options_label.get_rect(center=options_button.center))
    screen.blit(quit_label, quit_label.get_rect(center=quit_button.center))
    screen.blit(toggle_label, toggle_label.get_rect(center=mode_toggle_button.center))
    pygame.draw.rect(screen, (70, 70, 70), save_button, border_radius=8)
    pygame.draw.rect(screen, (70, 70, 70), load_button, border_radius=8)

    screen.blit(save_label, save_label.get_rect(center=save_button.center))
    screen.blit(load_label, load_label.get_rect(center=load_button.center))

def draw_options_menu():
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)  # Enable alpha channel
    overlay.fill((30, 30, 30, 180))  # RGBA: semi-transparent dark overlay
    screen.blit(overlay, (0, 0))

    pygame.draw.rect(screen, (70, 70, 70), back_button, border_radius=8)
    back_label = font.render("Back", True, (255, 255, 255))
    screen.blit(back_label, back_label.get_rect(center=back_button.center))

    title = font.render("Options Menu", True, (255, 255, 255))
    screen.blit(title, title.get_rect(center=(WIDTH // 2, 100)))

    pygame.draw.rect(screen, (100, 100, 100), input_box, border_radius=4)
    world_name_display = world_name + ("|" if editing_name else "")
    name_text = font.render(f"World Name: {world_name_display}", True, (255, 255, 255))
    screen.blit(name_text, (input_box.x + 10, input_box.y + 5))

    if spawn_Zombies:
        iszombieon = "on"
    else:
        iszombieon = "off"
    pygame.draw.rect(screen, (100,100,100), zombie_toggle_button, border_radius=4)
    zombies_label = font.render(f"Toggle Zombies: {iszombieon}", True, (255, 255, 255))
    screen.blit(zombies_label, (zombie_toggle_button.x + 10, zombie_toggle_button.y + 5))

    if survival:
        survivalstat = "on"
    else:
        survivalstat = "off"
    pygame.draw.rect(screen, (100, 100, 100), survival_toggle_button, border_radius=4)
    survival_label = font.render(f"Toggle survival: {survivalstat}", True, (255, 255, 255))
    screen.blit(survival_label, (survival_toggle_button.x + 10, survival_toggle_button.y + 5))

def find_spawn_point():
    for row in range(ROWS):
        for col in range(COLS):
            if world[row][col].tile_id == TILE_SPAWN:
                return col * TILE_SIZE, row * TILE_SIZE
    return 400, 400  # fallback position

def list_saves():
    saves = [f for f in os.listdir() if f.startswith(PREFIX) and f.endswith(".json")]
    return saves

def save_game(filepath=None):
    # Build the data in JSON-serializable types only (dicts/lists/ints/strings/bools)
    data = {
        "version": 1,
        "world_name": world_name,
        "rows": ROWS,
        "cols": COLS,
        "tile_size": TILE_SIZE,
        "world": [[tile.tile_id for tile in row] for row in world],
        "spawn_point": list(spawn_point) if spawn_point else None,
        "player": {
            "x": player.rect.x,
            "y": player.rect.y,
            "w": player.rect.width,
            "h": player.rect.height,
            "health": player.health,
            "speed": player.speed,
            "color": list(player.color) if isinstance(player.color, tuple) else player.color,
            "points": player.points,
            "weapons": player.weapons,
            "weapon": player.weapon,
            "arsenal": player.arsenal,
            "image": player.img
        },
        "options": {
            "spawn_Zombies": spawn_Zombies,
            "survival": survival,
        }
    }


    # Where to save
    filename = filepath or f"{PREFIX}{world_name}.json"

    # Safer "atomic" save: write to temp then replace
    tmp = filename + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, filename)
    return(f"Saved to {filename}")

def load_game(filepath=None):
    global world, world_name, spawn_point, ROWS, COLS, TILE_SIZE
    global spawn_Zombies, survival

    filename = filepath or f"{PREFIX}{world_name}.json"
    if not os.path.exists(filename):
        print("Save file not found:", filename)
        return

    try:
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("Failed to read save:", e)
        return

    # --- Read metadata & options (with safe defaults) ---
    world_name = data.get("world_name", world_name)
    saved_rows = data.get("rows", ROWS)
    saved_cols = data.get("cols", COLS)
    TILE_SIZE = data.get("tile_size", TILE_SIZE)

    opts = data.get("options", {})
    spawn_Zombies = opts.get("spawn_Zombies", spawn_Zombies)
    survival = opts.get("survival", survival)

    # --- Rebuild world grid ---
    world_ids = data.get("world", [])
    # Create a new world with current ROWS/COLS (not the saved ones),
    # then copy overlap area; pad/crop as needed.
    new_world = [[Tile(TILE_EMPTY) for _ in range(COLS)] for _ in range(ROWS)]
    for r in range(min(ROWS, saved_rows, len(world_ids))):
        row_ids = world_ids[r]
        for c in range(min(COLS, saved_cols, len(row_ids))):
            new_world[r][c] = Tile(row_ids[c])
    world = new_world

    # --- Rebuild spawn point ---
    sp = data.get("spawn_point", None)
    spawn_point = tuple(sp) if sp else None

    # --- Rebuild player ---
    player_data = data.get("player", {})
    px = player_data.get("x", player.rect.x)
    py = player_data.get("y", player.rect.y)
    pw = player_data.get("w", player.rect.width)
    ph = player_data.get("h", player.rect.height)
    player.rect = pygame.Rect(px, py, pw, ph)
    player.health = player_data.get("health", player.health)
    player.speed = player_data.get("speed", player.speed)
    pcolor = player_data.get("color", player.color)
    player.color = tuple(pcolor) if isinstance(pcolor, list) else pcolor
    player.points = player_data.get("points", player.points)
    player.weapons = player_data.get("weapons", list(arsenal.keys()))
    player.weapon = player_data.get("weapon", 0)
    player.arsenal = player_data.get("arsenal", arsenal)
    player.img = player_data.get("image", player_img)

    return(f"Loaded from {filename}")

def select_save_menu(saves):
    selected_index = 0
    selecting = True

    while selecting:
        screen.fill((30, 30, 30))  # Dark background
        title = font.render("Select a Save", True, (255, 255, 255))
        subtitle = font.render("press [up]/[down] to select and [enter] to start", True, (255, 255, 255))
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 50))
        screen.blit(subtitle, (WIDTH//2 - subtitle.get_width()//2, 75))

        # Draw the list of saves
        for i, s in enumerate(saves):
            color = (255, 255, 0) if i == selected_index else (200, 200, 200)
            save_text = font.render(s, True, color)
            screen.blit(save_text, (WIDTH//2 - save_text.get_width()//2, 150 + i * 30))

        pygame.display.flip()
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected_index = max(0, selected_index - 1)
                elif event.key == pygame.K_DOWN:
                    selected_index = min(len(saves)-1, selected_index + 1)
                elif event.key == pygame.K_RETURN:
                    selecting = False

    return saves[selected_index]

def collides_with_solid(rect, solids):
    # Loop through nearby tiles only for efficiency
    start_row = max((rect.top - camera_y) // TILE_SIZE, 0)
    end_row = min((rect.bottom + camera_y) // TILE_SIZE, ROWS - 1)
    start_col = max((rect.left - camera_x) // TILE_SIZE, 0)
    end_col = min((rect.right + camera_x) // TILE_SIZE, COLS - 1)

    for row in range(start_row, end_row + 1):
        for col in range(start_col, end_col + 1):
            tile = world[row][col]
            if tile.tile_id in solids:
                tile_rect = pygame.Rect(col*TILE_SIZE - camera_x, row*TILE_SIZE - camera_y, TILE_SIZE, TILE_SIZE)
                if rect.colliderect(tile_rect):
                    return True
    return False

def spawn_wave(wavenumber, value):
    global zombieframecount
    zombieframecount= 0
    use_zombs = []
    for i, zomb in enumerate(ZOMBIES):
        if wavenumber > ZOMBIES[zomb]["value"][0]:
            use_zombs.append((ZOMBIES[zomb]["value"][1], zomb))
    wavevalue = 0
    wave = []
    while value > wavevalue:
        if value - wavevalue == 1:
            for i, checkzomb in enumerate(use_zombs):
                if checkzomb[0] == 1:
                    wave.append(checkzomb[1])
                return(wave)
        elif value <= wavevalue:
            return(wave)
        else:
            checkzomb = random.choice(use_zombs)
            if checkzomb[0] > value - wavevalue:
                use_zombs.remove(checkzomb)
            else:
                wave.append(checkzomb[1])
                wavevalue += checkzomb[0]
    return(wave)

def open_inventory():
    global Hotbar, current_screen
    current_screen = "inventory"
    screen.fill((0,0,0))
    backrect = pygame.Rect(100, 100, WIDTH-200, HEIGHT-200)
    pygame.draw.rect(screen, (50, 50, 50), backrect, border_radius=5)

    tile_positions = []  # store clickable squares for later
    for i, tile_id in enumerate(Inventory):
        x = i * 50 + 110
        y = 110
        while x > (WIDTH - 160):
            x -= WIDTH - 270
            y += 50
        square = pygame.Rect(x, y, 40, 40)
        outlinesquare = pygame.Rect(x-2, y-2, 44, 44)
        tile_positions.append((square, tile_id))
        color = TILE_INFO[tile_id]["color"]
        pygame.draw.rect(screen, (0, 0, 0), outlinesquare, border_radius=3)
        pygame.draw.rect(screen, color, square)
        label = font.render(f"{TILE_INFO[tile_id]["name"]}", True, (20, 20, 20))
        labelpos = screen.get_rect(center=square.center)
        screen.blit(label, labelpos)
        
    draw_hotbar(False)

    pygame.draw.rect(screen, (220, 0, 0), inv_exit_button, border_radius=5)
    
    tempfont = pygame.font.Font(None, 36)
    textsurface = tempfont.render("X", True, (255, 255, 255))
    textspace = screen.get_rect(center = inv_exit_button.center)
    screen.blit(textsurface, textspace)
        


# Main game loop
running = True
while running:
    clock.tick(60)
    screen.fill((0, 0, 0))
    if label_refresh:
        label_refresh -= 1
    elif save_prelabel or load_prelabel:
        save_prelabel = None
        load_prelabel = None

    if current_screen in ("game", "resuming"):
        # Handle visual consistency
        draw_grid()
        draw_hotbar()
        draw_pause_button()
        draw_game_mode()
        

        if current_screen == "game":
            if game_mode == "play":
                update_tiles()
            place_tile()
            draw_points()
            if game_mode == "play":

                for projectile in projectiles[:]:
                    if not projectile.update():
                        projectiles.remove(projectile)
                    else:
                        projectile.draw(screen)
                if spawn_Zombies:
                    if len(zombies) == 0:
                        zombieframecount += 1
                    
                    if zombieframecount > 180:
                        waveready = True
                    
                    if waveready:
                        screen.blit(waveready_label, zombie_wave_button)
                    
                    for zombie in zombies[:]:
                        zombie.update()
                        zombie.draw(screen)
                        if collides_with_solid(zombie.rect, [TILE_FIRE]):
                            zombies.remove(zombie)
                            player.points += 1
                            break
                        for proj in projectiles[:]:
                            for z in zombies[:]:
                                if proj.rect.colliderect(z.rect):
                                    z.health -= proj.damage
                                    projectiles.remove(proj)
                                    if z.health <= 0:
                                        zombies.remove(z)
                                        player.points += 5*zombie.stats["value"][1]
                                    break


                else: zombies = []
                
                if survival:
                    for zombie in zombies[:]:
                        if zombie.rect.colliderect(player.rect):
                            zombie.attack( player)
                    if player.health > 0:
                        player.update(screen)
                    else:
                        deathprompt = font.render("press z to respawn", True, (255, 255, 255))
                        screen.blit(deathprompt, (WIDTH // 2 + camera_x, HEIGHT // 2 + camera_y))
                    player.draw_health_bar(screen)


        elif current_screen == "resuming":
            pause_cooldown -= 1
            if pause_cooldown <= 0:
                current_screen = "game"
    elif current_screen == "pause":
        draw_grid()
        draw_hotbar()
        draw_pause_button()
        draw_pause_menu()

    elif current_screen == "options":
        draw_options_menu()
    
    elif current_screen == "inventory":
        open_inventory()
    

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.VIDEORESIZE:
            # Clamp size to minimums
            new_width = max(WIDTH, event.w)
            new_height = max(HEIGHT, event.h)
            screen = pygame.display.set_mode((new_width, new_height), pygame.RESIZABLE)

        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            if current_screen == "game":
                if event.button == 2:
                    mousewheeldown = True
                elif event.button == 4:
                    if game_mode == "build":
                        if selected_tile > 0:
                            selected_tile -= 1
                        else:
                            selected_tile = len(Hotbar)-1
                    elif game_mode == "play":
                        if mousewheeldown:
                            if selected_tile > 0:
                                selected_tile -= 1
                            else:
                                selected_tile = len(Hotbar)-1
                        else:
                            player.totaldelay = 0
                            if player.reloading:
                                Reloadchannel.stop()
                                player.arsenal[player.weapons[player.weapon]]["ammo"] = 0
                                player.reloading = False
                            if player.weapon > 0:
                                player.weapon -= 1
                            else:
                                player.weapon = len(player.weapons)-1
                            player.firedelay = player.arsenal[player.weapons[player.weapon]]["mobility"]*30
                elif event.button == 5:
                    if game_mode == "build":
                        if selected_tile < (len(Hotbar)-1):
                            selected_tile += 1
                        else:
                            selected_tile = 0
                    elif game_mode == "play":
                        if mousewheeldown:
                            if selected_tile < (len(Hotbar)-1):
                                selected_tile += 1
                            else:
                                selected_tile = 0
                        else:
                            player.totaldelay = 0
                            if player.reloading:
                                Reloadchannel.stop()
                                player.arsenal[player.weapons[player.weapon]]["ammo"] = 0
                                player.reloading = False
                            if player.weapon < len(player.weapons)-1:
                                player.weapon += 1
                            else:
                                player.weapon = 0
                            player.firedelay = player.arsenal[player.weapons[player.weapon]]["mobility"]*30
                elif event.button == 1:
                    if game_mode == "play":
                        player.firing = True
                if pause_button.collidepoint(mouse_pos):
                    current_screen = "pause"
                elif Inventory_button.collidepoint(mouse_pos):
                    current_screen = "inventory"
                    open_inventory()
                elif HOTBAR_RECT.collidepoint(mouse_pos):
                    for i in range(len(Hotbar)):
                        tile_id = Hotbar[i]
                        x = 20 + i * 60
                        y = HEIGHT - 50
                        tile_rect = pygame.Rect(x, y, 40, 40)
                        if tile_rect.collidepoint(mouse_pos):
                            selected_tile = i
                            break
                elif zombie_wave_button.collidepoint(mouse_pos):
                    if waveready:
                        wavedifficulty = wavenum * 2 * difficulty_index[difficulty]["wave mult"]
                        prezombies = spawn_wave(wavenum, wavedifficulty)
                        for i, z in enumerate(prezombies):
                            zombies.append(Zombie(player.rect, ZOMBIES[z]))
                        wavenum += 1
                        zombieframecount = 0
                        waveready = False
                        suppress_click = 15
                    
            elif current_screen == "pause":
                if resume_button.collidepoint(mouse_pos):
                    current_screen = "resuming"
                    pause_cooldown = 15
                    suppress_click = 15
                elif save_button.collidepoint(mouse_pos):
                    save_prelabel = save_game()
                    label_refresh = 60
                    suppress_click = 15
                elif load_button.collidepoint(mouse_pos):
                    load_prelabel = load_game()
                    label_refresh = 60
                    select_save_menu(list_saves())
                    suppress_click = 15
                elif options_button.collidepoint(mouse_pos):
                    current_screen = "options"
                elif quit_button.collidepoint(mouse_pos):
                    running = False
                elif mode_toggle_button.collidepoint(mouse_pos):
                    if game_mode == "build":
                        if spawn_point:
                            game_mode = "play"
                            player.reset(spawn_point[0], spawn_point[1])
                        else:
                            game_mode = "play"
                    else:
                        game_mode = "build"
                    suppress_click = 15

            elif current_screen == "options":
                if zombie_toggle_button.collidepoint(mouse_pos):
                    spawn_Zombies = not spawn_Zombies
                elif back_button.collidepoint(mouse_pos):
                    current_screen = "pause"
                elif survival_toggle_button.collidepoint(mouse_pos):
                    survival = not survival
                elif input_box.collidepoint(mouse_pos):
                    editing_name = True
                else:
                    editing_name = False
            
            elif current_screen == "inventory":
                if inv_exit_button.collidepoint(mouse_pos):
                    current_screen = "game"
                    pause_cooldown = 15
                    suppress_click = 15
        
        elif event.type == pygame.MOUSEBUTTONUP:
            if current_screen == "game":
                if event.button == 1:
                    player.firing = False
                elif event.button == 2:
                    mousewheeldown = False
                    

        elif event.type == pygame.KEYDOWN:
            if current_screen == "game":
                if event.key == pygame.K_1:
                    selected_tile = 0
                elif event.key == pygame.K_2:
                    selected_tile = 1
                elif event.key == pygame.K_3:
                    selected_tile = 2
                elif event.key == pygame.K_4:
                    selected_tile = 3
                elif event.key == pygame.K_5:
                    selected_tile = 4
                elif event.key == pygame.K_6:
                    selected_tile = 5
                elif event.key == pygame.K_7:
                    selected_tile = 6
                elif event.key == pygame.K_8:
                    selected_tile = 7
                elif event.key == pygame.K_9:
                    selected_tile = 8
                elif event.key == pygame.K_0:
                    selected_tile = 9
                elif event.key == pygame.K_g:
                    if game_mode == "play" and waveready:
                        wavedifficulty = wavenum * 2 * difficulty_index[difficulty]["wave mult"]
                        prezombies = spawn_wave(wavenum, wavedifficulty)
                        for i, z in enumerate(prezombies):
                            zombies.append(Zombie(player.rect, ZOMBIES[z]))
                        wavenum += 1
                        zombieframecount = 0
                        waveready = False
                elif event.key == pygame.K_r:
                    player.reload()
                elif event.key == pygame.K_x:
                    WORLD_RESET()
                    camera_x = 0
                    camera_y = 0
                    zombies = []
                    player.reset(400, 400)
                elif event.key == pygame.K_q:
                    if game_mode == "build":
                        if spawn_point:
                            game_mode = "play"
                        else:
                            game_mode = "play"
                    else:
                        game_mode = "build"
                elif event.key == pygame.K_z:
                    player.health = 100
                    zombies = []
                    waveready = False
                    zombieframecount = 0
                    wavenum = 1
                elif event.key == pygame.K_SPACE:
                    if game_mode == "play":
                        player.shoot()
                elif event.key == pygame.K_p:
                    if pause_cooldown <= 0:
                        current_screen = "pause"
                        pause_cooldown = 20
                elif event.key == pygame.K_e:
                    current_screen = "inventory"
                    open_inventory()
                    
            
            elif current_screen == "pause":
                if event.key == pygame.K_p:
                    if pause_cooldown <= 0:
                        current_screen = "resuming"
                        pause_cooldown = 20

            elif current_screen == "options" and editing_name:
                if event.key == pygame.K_BACKSPACE:
                    world_name = world_name[:-1]
                elif event.key == pygame.K_RETURN:
                    editing_name = False
                else:
                    world_name += event.unicode


            elif current_screen == "options":
                if event.key == pygame.K_p:
                    if pause_cooldown <= 0:
                        current_screen = "resuming"
                        pause_cooldown = 20

            elif current_screen == "inventory":
                if event.key == pygame.K_e:
                    game_mode = "game"



    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        camera_y -= camera_speed
        player.rect.y += camera_speed
        if collides_with_solid(player.rect, solidlist):
            player.rect.y -= camera_speed
    if keys[pygame.K_DOWN]:
        camera_y += camera_speed
        player.rect.y -= camera_speed
        if collides_with_solid(player.rect, solidlist):
            player.rect.y += camera_speed
    if keys[pygame.K_LEFT]:
        camera_x -= camera_speed
        player.rect.x += camera_speed
        if collides_with_solid(player.rect, solidlist):
            player.rect.x -= camera_speed
    if keys[pygame.K_RIGHT]:
        camera_x += camera_speed
        player.rect.x -= camera_speed
        if collides_with_solid(player.rect, solidlist):
            player.rect.x += camera_speed
    
    if not survival:
        player.update(screen)
    
    mouse_x, mouse_y = pygame.mouse.get_pos()
    screen.blit(cursor_img, (mouse_x - cursor_img.get_width()//2, mouse_y - cursor_img.get_height()//2))


    pygame.display.flip()

pygame.quit()
sys.exit()

#extra space
#
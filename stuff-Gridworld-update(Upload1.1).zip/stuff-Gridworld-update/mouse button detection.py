import pygame
import time

pygame.init()
screen = pygame.display.set_mode((300, 400))
pygame.display.set_caption("Mouse Button Visualizer")

WHITE = (240, 240, 240)
GRAY = (100, 100, 100)
GREEN = (0, 200, 0)
RED = (200, 0, 0)

font = pygame.font.SysFont(None, 28)

running = True
pressed_buttons = set()

# Store scroll flashes (button: expire_time)
scroll_flash = {}

FLASH_DURATION = 0.2  # seconds

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pressed_buttons.add(event.button)

            # Scroll events in pygame:
            # 4 = scroll up, 5 = scroll down
            if event.button in (4, 5):
                scroll_flash[event.button] = time.time() + FLASH_DURATION

        elif event.type == pygame.MOUSEBUTTONUP:
            pressed_buttons.discard(event.button)
    


    screen.fill((30, 30, 30))

    # Draw mouse body
    pygame.draw.rect(screen, WHITE, (100, 50, 100, 250), border_radius=40)

    # Left button
    color = GREEN if 1 in pressed_buttons else GRAY
    pygame.draw.rect(screen, color, (105, 55, 45, 100), border_radius=10)

    # Right button
    color = GREEN if 3 in pressed_buttons else GRAY
    pygame.draw.rect(screen, color, (150, 55, 45, 100), border_radius=10)

    # Middle button (wheel click)
    color = GREEN if 2 in pressed_buttons else GRAY
    pygame.draw.rect(screen, color, (140, 100, 20, 40), border_radius=5)

    # Side buttons (4 + 5 in normal mice, but here we treat them as extra)
    color = GREEN if 6 in pressed_buttons else GRAY
    pygame.draw.circle(screen, color, (90, 170), 15)
    color = GREEN if 7 in pressed_buttons else GRAY
    pygame.draw.circle(screen, color, (90, 130), 15)

    # Draw scroll flashes
    now = time.time()
    if 4 in scroll_flash and scroll_flash[4] > now:  # scroll up
        pygame.draw.polygon(screen, GREEN, [(140, 90), (160, 90), (150, 70)])
        pressed_buttons.add(4)
    if 5 in scroll_flash and scroll_flash[5] > now:  # scroll down
        pygame.draw.polygon(screen, GREEN, [(140, 150), (160, 150), (150, 170)])
        pressed_buttons.add(5)
        
    # Debug text
    text = font.render(f"Pressed: {sorted(pressed_buttons)}", True, (200, 200, 200))
    screen.blit(text, (50, 330))
    
    if 4 in pressed_buttons:
        pressed_buttons.discard(4)
    elif 5 in pressed_buttons:
        pressed_buttons.discard(5)

    pygame.display.flip()

pygame.quit()
